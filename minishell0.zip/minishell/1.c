#include <unistd.h>

int main()
{
  write(1, "Hello", 1);
  return (0);
}
