/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbeqqo <gbeqqo@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/23 16:47:35 by gbeqqo            #+#    #+#             */
/*   Updated: 2019/07/24 16:18:36 by gbeqqo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include <stdio.h>

char	*create_path(char *name, char *path)
{
	char *new;
	char *res;

	if (ft_strcmp(path, "/") != 0)
		new = ft_strjoin(path, "/");
	else
		new = path;
	res = ft_strjoin(new, name);
	if (ft_strcmp(path, "/") != 0)
		free(new);
	return (res);
}

void	print_shell_name()
{
	ft_putstr("♿  \e[96m\e[1mminishell \e[0m");
}

char	*ft_getenv(const char *name, char **envp)
{
	int i;
	char *ret;
	int len;

	i = 0;
	len = ft_strlen(name) + 1;
	while (envp[i])
	{
		ret = ft_strstr(envp[i], name);
		if (ret != NULL)
			return (ft_strdup(ret + len));
		i++;
	}
	return (NULL);
}

void	free_parse(char **parse, int w)
{
	int i;

	i = 0;
	w++;
	while (i < w)
	{
		free(parse[i]);
		i++;
	}
	free(parse);
}

int		check_builtin(char *cmd)
{
	if (ft_strcmp(cmd, "echo") == 0)
		return (1);
	if (ft_strcmp(cmd, "cd") == 0)
		return (1);
	if (ft_strcmp(cmd, "setenv") == 0)
		return (1);
	if (ft_strcmp(cmd, "unsetenv") == 0)
		return (1);
	if (ft_strcmp(cmd, "env") == 0)
		return (1);
	if (ft_strcmp(cmd, "exit") == 0)
		return (1);
	return (0);
}

int		execute_builtin(char **parse, char **envp)
{
	envp++;
	if (ft_strcmp(parse[0], "echo") == 0)
		return (1);
	if (ft_strcmp(parse[0], "cd") == 0)
		return (1);
	if (ft_strcmp(parse[0], "setenv") == 0)
		return (1);
	if (ft_strcmp(parse[0], "unsetenv") == 0)
		return (1);
	if (ft_strcmp(parse[0], "env") == 0)
		return (1);
	if (ft_strcmp(parse[0], "exit") == 0)
		return (0);
	return (1);
}

int		open_dir(char *path_from_env, char *name)
{
	DIR *dir;
	struct dirent *d;

	dir = opendir(path_from_env);
	while ((d = readdir(dir)) != NULL)
	{
		if (ft_strcmp(d->d_name, name) == 0)
		{
			closedir(dir);
			return (1);
		}
	}
	closedir(dir);
	return (0);
}

void	free_split(char **split, int nbw)
{
	int i;

	i = 0;
	nbw++;
	while (i < nbw)
	{
		free(split[i]);
		i++;
	}
	free(split);
}

void	relative_execution(char *path, char **command, char **envp)
{
	char *exe_path;
	pid_t p;
	int w;

	exe_path = create_path(command[0], path);
	if (check_path(exe_path) == 0)
	{
		p = fork();
		if (p == -1)
		{
			ft_putendl("Can't fork");
			free(exe_path);
		}
		if (p == 0)
		{
			execve(exe_path, command, envp);
		}
		else
		{
			wait(&w);
			free(exe_path);
		}
	}
}

int		check_command(char **command, char **envp)
{
	char **split;
	char *env_path;
	int i;
	int words;

	i = 0;
	env_path = ft_getenv("PATH", envp);
	words = count_words_delim(env_path, ':');
	split = ft_split_delim(env_path, words, ':');
	while (split[i])
	{
		if (open_dir(split[i], command[0]) == 1)
		{
			relative_execution(split[i], command, envp);
			free_parse(split, words);
			free(env_path);
			return (1);
		}
		i++;
	}
	free(env_path);
	free_parse(split, words);
	return (0);
}

int		check_path(char *path)
{
	struct stat s;

	if ((lstat(path, &s)) == -1)
	{
		ft_putstr("minishell: No such file or directory: ");
		ft_putendl(path);
		return (-1);
	} 
	if (access(path, X_OK) == -1)
	{
		ft_putstr("minishell: Permission denied: ");
		ft_putendl(path);
		return (-1);
	}
	return (0);
}

int		absolute_execution(char **parse, char **envp)
{
	int test;
	pid_t p;
	int stat;

	test = check_path(parse[0]);
	if (test == 0)
	{
		p = fork();
		if (p == -1)
		{
			ft_putendl("Can't fork");
			return (1);
		}
		if (p == 0)
		{
			execve(parse[0], parse, envp);
		}
		else
		{
			wait(&stat);
		}
	}
	return (1);
}

int		execute_command(char **parse, char **envp)
{
	int check;

	if (parse[0][0] == '.' || parse[0][0] == '/')
	{
		check = absolute_execution(parse, envp);
	}
	else
	{
		check = check_command(parse, envp);
	}
	return (1);
}

int		count_pointers(char **envp)
{
	int i;

	i = 0;
	while (envp[i])
		i++;
	return (i);
}

void	copy_env_to(char **envp, char **copy)
{
	int i;
	int j;

	i = 0;
	j = 0;
	while (envp[i])
	{
		j = 0;
		while(envp[i][j] != '\0')
		{
			copy[i][j] = envp[i][j];
			j++;
		}
		copy[i][j] = '\0';
		i++;
	}
}

char	**create_env_copy(char **envp, int c)
{
	char **copy;
	
	int i;

	i = 0;
	
	copy = (char **)malloc(sizeof(char *) * (c + 1));
	while (i < c)
	{
		copy[i] = (char *)malloc(sizeof(char) * (ft_strlen(envp[i]) + 1));
		i++;
	}
	copy[i] = NULL;
	copy_env_to(envp, copy);
	return (copy);
}

int		take_command(char *cmd, char **envp)
{
	int words;
	char **parse;
	char **copy_envp;
	int status;
	int p_count;

	p_count = count_pointers(envp);
	copy_envp = create_env_copy(envp, p_count);
	status = 1;
		words = count_words(cmd);
		parse = ft_full_split(cmd, words);
		if (parse[0])
		{
			if (check_builtin(parse[0]) == 1)
				status = execute_builtin(parse, copy_envp);
			else
				status = execute_command(parse, copy_envp);
		}
		free_parse(parse, words);
	free_parse(copy_envp, p_count);
	return (status);
}

void	handle_sig(int sig)
{
	if (sig == 2)
		return ;
}

int		main(int argc, char **argv, char **envp)
{
	char *cmd;
	int status;
	int gnl;

	status = 1;
	(void)argv;
	cmd = NULL;
	if (argc == 1)
	{
		while (status)
		{
			print_shell_name();
			signal(SIGINT, handle_sig);
			gnl = get_next_line(0, &cmd);
			if (gnl == 1)
			{
				status = take_command(cmd, envp);
				free(cmd);
			}
			if (gnl == 0)
				break;
		}
	}
	return (0);
}
