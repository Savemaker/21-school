/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbeqqo <gbeqqo@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/23 16:47:55 by gbeqqo            #+#    #+#             */
/*   Updated: 2019/07/23 17:08:01 by gbeqqo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
# define MINISHELL_H
# include "libft/includes/libft.h"
# include <dirent.h>
# include <sys/stat.h>
# include <sys/wait.h>
# include <signal.h>

int		count_words(char *cmd);
int		*create_tab(int words);
int		*count_each_word(char *cmd, int words);
void	copy_split(char **res, char *cmd);
char	**ft_full_split(char *cmd, int words);
void	copy_split_delim(char **res, char *cmd, char delim);
int		*count_each_word_delim(char *cmd, int words, char delim);
char    **ft_split_delim(char *cmd, int words, char delim);
int		count_words_delim(char *cmd, char delim);

int		check_path(char *path);
int		count_pointers(char **envp);

#endif