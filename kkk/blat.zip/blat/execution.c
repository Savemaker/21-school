/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   execution.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bellyn-t <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/07 21:14:18 by bellyn-t          #+#    #+#             */
/*   Updated: 2019/09/08 13:51:30 by bellyn-t         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"


int ft_nbrlen(int nb)
{
	int i;

	i = 1;
	if (nb == 0)
		return (i);
	while (nb / 10 > 0)
	{
		nb /= 10;
		i++;
	}
	return (i);
}


int display_history(char **cmnd)
{
	int num;
	int i;
	int argc;
	int space = 0;
	int i_len;

	argc = str_quantity(cmnd);

	if (g_shell->history->index >= HISTFILESIZE)
		i = g_shell->history->index - HISTFILESIZE;
	else
		i = 0;

	if (argc > 2)
	{
		ft_putstr_fd("usage: history [value]\n", STDOUT_FILENO);
		return (1);
	}
	if (argc > 1)
	{
		if ((num = ft_atoi(cmnd[1])) == 0 || num > g_shell->history->index)
		{
			ft_putstr_fd("history: invalid value\n", STDOUT_FILENO);
			return (1);
		}
		else
			i = g_shell->history->index - num;
	}
	int maxlen;
	maxlen = ft_nbrlen(g_shell->history->index);
	while (g_shell->history->cmnds[i])
	{
		i_len = ft_nbrlen(i + 1);
		space = maxlen - i_len + 1;
		ft_putnbr_fd(i + 1, STDOUT_FILENO);
		while (space--)
			ft_putstr_fd(" ", STDOUT_FILENO);
		ft_putstr_fd(g_shell->history->cmnds[i], STDOUT_FILENO);
		ft_putchar_fd('\n', STDOUT_FILENO);
		i++;
	}

	return (1);
}
int		execute_cmnd(char **cmnd)
{
	int		execute_status;
	char	*path;

	execute_status = 1;
	if (cmnd[0] == NULL)
		return (1);
	else if (*cmnd[0] == '/' || *cmnd[0] == '.')
		execute_status = absolute_path_launch(cmnd);
	else if (check_builtin(cmnd[0]) == 1)
		execute_status = builtin(cmnd);
	else if ((path = check_extern_command(cmnd, -1)))
		execute_status = external_launch(cmnd, path);
	else
		perror_cmnd(SHELLNAME, cmnd[0], CMNDNTFND);
	return (execute_status);
}

int		exe_multcmnds(char *line)
{
	int		i;
	char	**args;
	char	**mult_args;
	int		status;

	status = 1;
	if (!(args = ft_strsplit(line, ';')))
		perror_cmnd(SHELLNAME, NULL, MLKERR);
	i = -1;
	while (args[++i])
	{
		mult_args = split_cmnd(args[i], ' ');
		status = execute_cmnd(mult_args);
		clean_env(mult_args);
		if (status == 0)
			break ;
	}
	clean_env(args);
	return (status);
}

int		exe_cmnds(char *line)
{
	char	**args;
	int		status;

	//his add
	args = split_cmnd(line, ' ');
	status = execute_cmnd(args);
	clean_env(args);
	return (status);
}

int		execution(char *line)
{
	int status;

	if ((ft_strrchr(line, ';')))
		status = exe_multcmnds(line);
	else
		status = exe_cmnds(line);
	free(line);
	return (status);
}
