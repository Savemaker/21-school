/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   shell_loop.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bellyn-t <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/08 13:48:14 by bellyn-t          #+#    #+#             */
/*   Updated: 2019/09/08 13:48:17 by bellyn-t         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

//`co' always has a numeric value,
// while `am' (automatic wrap at margin) is always a flag,
// and `cm' (cursor motion command) always has a string value.

//Use tgetnum to get a capability value that is numeric.
// The argument name is the two-letter code name of the capability.
// If the capability is present, tgetnum returns the numeric value (which is nonnegative).
// If the capability is not mentioned in the terminal description, tgetnum returns -1.

//tgetflag
//Use tgetflag to get a boolean value.
// If the capability name is present in the terminal description, tgetflag returns 1; otherwise, it returns 0.
//tgetstr

//Use tgetstr to get a string value.
// It returns a pointer to a string which is the capability value,
// or a null pointer if the capability is not present in the terminal description.


int		str_quantity(char **env)
{
	int i;

	i = 0;
	while (env[i])
		i++;
	return (i);
}

int display_user(void)
{
	char	*user;
	int len;
//	if (!g_shell.error)
		ft_putstr_fd(BGREEN, STDOUT_FILENO);
//	else
//		ft_putstr_fd(BRED, STDOUT_FILENO);
	if ((user = getenv_cmnd("USER")))
	{
		ft_putstr_fd(user, STDOUT_FILENO);
		len = (int)ft_strlen(user);
	}
	else
	{
		ft_putstr_fd(SHELLNAME, STDOUT_FILENO);
		len = (int)ft_strlen(SHELLNAME);
	}
	return (len);
}

int display_host(void)
{
	char	host[MAXHOSTNAME];

	gethostname(host, MAXHOSTNAME);
	ft_putchar_fd('@', STDOUT_FILENO);
	ft_putstr_fd(host, STDOUT_FILENO);
	return ((int)ft_strlen(host) + 1);
}

int display_cwd(void)
{
	char	*cwd;
	char 	*newcwd;
	char 	*val;
	int 	len;

	len = 0;
	if ((cwd = getcwd(NULL, 0)))
	{
		ft_putstr_fd(WHITE, STDOUT_FILENO);
		ft_putstr_fd(":", STDOUT_FILENO);
		ft_putstr_fd(BCYAN, STDOUT_FILENO);
		val = getenv_cmnd("HOME");
		if (!ft_strncmp(cwd, val, ft_strlen(val)))
		{
			newcwd = ft_strjoin("~", cwd + ft_strlen(val));
			ft_putstr(newcwd);
			len = (int)ft_strlen(newcwd);
			free(newcwd);
		}
		else
		{
			ft_putstr_fd(cwd, STDOUT_FILENO);
			len = (int)ft_strlen(cwd);
		}
	}
	free(cwd);
	return (len + 1);
}

int display_ordinary_prompt()
{
	int len;

	len = 0;
	len += display_user();
	len += display_host();
	len += display_cwd();
	if (!g_shell->error)
		ft_putstr_fd(BGREEN, STDOUT_FILENO);
	else
		ft_putstr_fd(BRED, STDOUT_FILENO);
//	ft_putstr_fd("$ ", STDOUT_FILENO);
	ft_putstr_fd(" ➜  ", STDOUT_FILENO);
	ft_putstr_fd(RESET, STDOUT_FILENO);
	return (len + 4);
}

void display_def_prompt(char *defprompt)
{
defprompt = NULL;
}

int ft_putchar_int(int c)
{
	write(STDOUT_FILENO, &c, 1);
	return (1);
}

int	init_keypad_transmitmode(void)
{
	if (tgetstr("ks", NULL))
		tputs(tgetstr("ks", NULL), 1, &ft_putchar_int);
	else
	{
		ft_putchar_fd('\n', STDOUT_FILENO);
		perror_cmnd(SHELLNAME, "no correct capabilities", 0);
		return (0);
	}
	return (1);
}

int display_prompt(void)
{
	int len;

	set_input_tmode();

//	if ((default_prompt = getenv_cmnd("PS1")))
//		display_def_prompt(default_prompt);
//	else
	len = display_ordinary_prompt();
	reset_input_tmode();
	return (len);
}

t_readline *init_readline(int prompt_size)
{
	struct winsize	win;
	t_readline *input;

	int savemode = 0;

	if (g_shell->input)
		savemode = g_shell->input->mode;
	input = ft_memalloc(sizeof(t_readline));
	input->mode = savemode;
//	ft_bzero(input, sizeof(t_readline));
	input->line = ft_memalloc(MAXLINE);
	input->clipboard = ft_memalloc(MAXLINE);
	if ((ioctl(STDIN_FILENO, TIOCGWINSZ, &win)) == -1)
	{
		ft_putchar('\n');
		perror_cmnd(SHELLNAME, NULL, IOCTLERR);
		exit_clean();
	}
	input->maxwidth = win.ws_col;
	input->maxheight = win.ws_row;
	if (prompt_size >= (input->maxwidth))
	{
		input->prompt_end = prompt_size % (input->maxwidth);
		if (input->prompt_end == 0)
			TDOWN;
	}
	else
		input->prompt_end = prompt_size;
	input->x = input->prompt_end;
	input->prompt_size = prompt_size;
	return (input);
}

void goto_linestart(t_readline *input)
{
	int  strn;

	if (input->y)
	{
		strn = input->y;
		while (strn--)
			TUP;
	}
	TLEFT_BORDER;
}

void goto_inputstart(t_readline *input)
{
	int prompt;

	goto_linestart(input);
	prompt = input->prompt_end;
	while (prompt--)
		TRIGHT;
}

void clear_visible_line(t_readline *input)
{
	TCLEAR_STR; //очистить строку
	goto_inputstart(input);
}

void print_line(t_readline *input, int eof)
{
	clear_visible_line(input);
	ft_putstr_fd(input->line, STDOUT_FILENO);
	if (eof)
	    ft_putchar_fd('\n', STDOUT_FILENO);
}

void cursor_right(t_readline *input)
{
	int fullstrsize;

	fullstrsize = input->prompt_end + input->size;
	if ((input->y * (input->maxwidth) + input->x)< fullstrsize)
	{
		if (input->x < input->maxwidth - 1)
		{
			input->x++;
			TRIGHT;
		}
		else
		{
			input->y++;
			input->x = 0;
			TLEFT_BORDER;// левая граница тек строки
			TDOWN;
		}
	}
	else
		TBELL;
}

void cursor_left(t_readline *input)
{
	int i;


	if ((input->y == 0 && input->x > input->prompt_end) || (input->y > 0 && input->x > 0))
	{
		TLEFT;
		input->x--;
	}
	else if (input->y > 0 && input->x == 0)
	{
		TUP;
		i = input->maxwidth - 1;
		while (i--)
			TRIGHT;
		input->x = input->maxwidth -1;
		input->y--;
	}
	else
		TBELL;
}

void	cursor_up(t_readline *input)
{
	if (input->y > 1)
	{
		TUP;
		input->y--;
	}
	else if (input->y == 1 && input->x >= input->prompt_end)
	{
		TUP;
		input->y--;
	}
	else if (input->y == 1 && input->x < input->prompt_end)
	{
		goto_inputstart(input);
		input->x = input->prompt_end;
		input->y--;
	}
	else
		TBELL;
}

void	goto_lastsymb(t_readline *input)
{
	int fullstrsize;
	int	maxstrn;
	int	i;

	fullstrsize = input->prompt_end + input->size;
	maxstrn = fullstrsize / (input->maxwidth);
	if ((fullstrsize % input->maxwidth) == 0)
		maxstrn--;
	while (maxstrn--)
		TUP;
	TLEFT_BORDER;
	i = 0;
	while (i++ < input->y)
		TDOWN;
	i = 0;
	while (i++ < input->x)
		TRIGHT;

}

void	cursor_down(t_readline *input)
{
	int lastxpos;
	int fullstrsize;

	fullstrsize = input->prompt_end + input->size;
	if ((input->y + 1) * input->maxwidth + input->x < fullstrsize)
	{
		lastxpos = input->x;
		TDOWN;
		while (lastxpos--)
			TRIGHT;
		input->y++;
	}
	else if (((input->y + 1) * input->maxwidth <= fullstrsize))
	{
		while ((input->y * input->maxwidth + input->x) < fullstrsize)
			cursor_right(input);
	}
	else
		TBELL;
}


void goto_start(t_readline *input)
{
	goto_inputstart(input);
	input->x = input->prompt_end;
	input->y = 0;
}

void goto_end(t_readline *input)
{
	int fullstrsize;

	fullstrsize = input->prompt_end + input->size;
	while (input->y * input->maxwidth + input->x < fullstrsize)
		cursor_right(input);
}

void goto_next_word(t_readline *input)
{
	int pos;

	pos = input->y * input->maxwidth + input->x - input->prompt_end;
	while (input->line[pos] && !ft_isspace(input->line[pos]))
	{
		pos++;
		cursor_right(input);
	}
	while (input->line[pos] && ft_isspace(input->line[pos]))
	{
		pos++;
		cursor_right(input);
	}
}

void goto_prev_word(t_readline *input)
{
	int pos;

	pos = input->y * input->maxwidth + input->x - input->prompt_end;
	if (pos && (!(ft_isspace(input->line[pos]) && ft_isspace(input->line[pos - 1])) || !input->line[pos]))
	{
		pos--;
		cursor_left(input);
	}
	while (pos && input->line[pos] && ft_isspace(input->line[pos]))
	{
		pos--;
		cursor_left(input);
	}
	while (pos && input->line[pos] && !ft_isspace(input->line[pos]))
	{
		pos--;
		cursor_left(input);
	}
	if (pos > 0)
		cursor_right(input);
}

static void	cursor_motion(t_readline *input, char *buf) //ok
{
//	if (!ft_strcmp(buf, tgetstr("nd", NULL)))
//	if (!ft_strcmp(buf, tgetstr("kr", NULL)))
    if (!ft_strcmp(buf, RIGHT_KEY))
		cursor_right(input);

	if (!ft_strcmp(buf, LEFT_KEY))
//	if (!ft_strcmp(buf, tgetstr("kl", NULL)))
		cursor_left(input);
//	if (!ft_strcmp(buf, tgetstr("ku", NULL)))
	else if (!ft_strcmp(buf, UP_KEY))
		cursor_up(input);
//	if (!ft_strcmp(buf, tgetstr("kd", NULL)))
	else if (!ft_strcmp(buf, DOWN_KEY))//
		cursor_down(input);
	else if (!ft_strcmp(buf, CTRL_A) || !ft_strcmp(buf, FN_LEFT)) ////ctrl A  || fn < (home)
//	else if (!ft_strcmp(buf, CTRL_A) || !ft_strcmp(buf,tgetstr("kh", NULL))) ////ctrl A  || fn < (home)
		goto_start(input);
	else if (!ft_strcmp(buf, CTRL_E) || !ft_strcmp(buf, FN_RIGHT)) ////ctrl E  || fn > (end)
//	else if (!ft_strcmp(buf, CTRL_E) || !ft_strcmp(buf, tgetstr("kh", NULL)))
		goto_end(input);
	else if (!ft_strcmp(buf, CTRL_F))
		goto_next_word(input);
	else if (!ft_strcmp(buf, CTRL_B))
		goto_prev_word(input);

}


//int	char_enter(char *buf, t_readline *input, int mode) //without his mode
//{
//	char	*residue;
//	int		pos;
//	int		bufsize;
//
//	if (ft_strrchr(buf, '\n'))
//	{
//		return 1;
//	}
//	bufsize = (int)ft_strlen(buf);
//	if (input->size < MAXLINE - bufsize)
//	{
//		pos = input->y * input->maxwidth + input->x - input->prompt_end;
//		residue = ft_strsub(input->line, (unsigned)pos, (size_t)input->size - pos);
//		ft_bzero(input->line + pos, (size_t)MAXLINE - pos);
//		input->line = ft_strcat(input->line, buf);
//		input->line = ft_strcat(input->line, residue);
//		clear_visible_line(input);
//		ft_putstr(input->line);
//		input->size += bufsize;
//		goto_lastsymb(input);
//		while (bufsize-- > 0)
//			cursor_right(input);
//		free(residue);
//	}
//	else
//		TBELL;
//	return (0);
//}

int	char_enter(char *buf, t_readline *input)
{
    char	*residue;
    int		pos;
    int		bufsize;

    if (ft_strrchr(buf, '\n'))
    {
        return 1;
    }
    bufsize = (int)ft_strlen(buf);
    if (input->size < MAXLINE - bufsize)
    {
        pos = input->y * input->maxwidth + input->x - input->prompt_end;
        residue = ft_strsub(input->line, (unsigned)pos, (size_t)input->size - pos);


        ft_bzero(input->line + pos, (size_t)MAXLINE - pos);
        input->line = ft_strcat(input->line, buf);
        input->line = ft_strcat(input->line, residue);
//        if (mode == HISTORY_INPUT)
//		{
//			input->line = ft_strcat(input->line, "': ");
//			input->size += 3;
//		}
        clear_visible_line(input);
        ft_putstr(input->line);
        input->size += bufsize;
        goto_lastsymb(input);
        while (bufsize-- > 0)
            cursor_right(input);
        free(residue);
    }
    else
        TBELL;
    return (0);
}

void	del_rightchar(t_readline *input)
{
	int		pos;
	char	*firstpart;
	char	*residue;

	pos = input->y * input->maxwidth + input->x - input->prompt_end;
	if (pos < input->size)
	{
		firstpart = ft_strsub(input->line, 0, (unsigned)pos);
		residue = ft_strsub(input->line, (unsigned)pos + 1, input->size - ft_strlen(firstpart));
		ft_bzero(input->line, MAXLINE);
		input->line = ft_strcpy(input->line, firstpart);
		input->line = ft_strcat(input->line, residue);
		free(firstpart);
		free(residue);
		clear_visible_line(input);
		ft_putstr(input->line);
		input->size--;
		goto_lastsymb(input);
	}
	else
		TBELL;
}

void	del_leftchar(t_readline *input)
{
	int		pos;
	char	*firstpart;
	char	*residue;

	pos = input->y * input->maxwidth + input->x - input->prompt_end;
	if (input->y > 0 || (input->y == 0 && input->x > input->prompt_end))
	{
		firstpart = ft_strsub(input->line, 0, (unsigned)pos - 1);
		residue = ft_strsub(input->line, (unsigned)pos, input->size - ft_strlen(firstpart));
		ft_bzero(input->line, MAXLINE);
		input->line = ft_strcpy(input->line, firstpart);
		input->line = ft_strcat(input->line, residue);
		clear_visible_line(input);
		ft_putstr(input->line);
		TDEL_CHAR;
		input->size--;
		goto_lastsymb(input);
		cursor_left(input);
		free(firstpart);
		free(residue);
	}
	else
		TBELL;
}

void clear_screen(t_readline *input)
{
	int i;

	i = 0;
	while (i++ < input->maxheight)
		TUP;
	clear_visible_line(input);
	TCLEAR_STR;
	TLEFT_BORDER;
	display_prompt();
	goto_inputstart(input);
	input->size = 0;
	input->y = 0;
	input->x = input->prompt_end;
	ft_bzero(input->line, MAXLINE);
}

void copy_after_cursor(t_readline *input)
{
	int pos;

	pos = input->y * input->maxwidth + input->x - input->prompt_end;
	ft_bzero(input->clipboard, MAXLINE);
	input->clipboard = ft_strncpy(input->clipboard, input->line + pos, (size_t)input->size - pos);
}

void copy_before_cursor(t_readline *input)
{
	int pos;

	pos = input->y * input->maxwidth + input->x - input->prompt_end;
	ft_bzero(input->clipboard, MAXLINE);
	input->clipboard = ft_strncpy(input->clipboard, input->line, (size_t)pos);
}

void cut_after_cursor(t_readline *input)
{
	int		pos;

	pos = input->y * input->maxwidth + input->x - input->prompt_end;
	ft_bzero(input->clipboard, MAXLINE);
	input->clipboard = ft_strncpy(input->clipboard, input->line + pos, (size_t)input->size - pos);
	ft_bzero(input->line + pos, MAXLINE - pos);
	input->size = (int)ft_strlen(input->line);
	clear_visible_line(input);
	ft_putstr(input->line);
	goto_lastsymb(input);
}


//void cut_before_cursor(t_readline *input)
//{
//	int pos;
//	int newsize;
//	char	*residue;
//	if (input->x > 0)
//	{
//		pos = input->y * input->maxwidth + input->x - input->prompt_end;
//		ft_bzero(input->clipboard, MAXLINE);
//		input->clipboard = ft_strncpy(input->clipboard, input->line, (size_t)pos);
//		newsize = input->size - (int)ft_strlen(input->clipboard);
//		residue = ft_strsub(input->line, (unsigned)pos, (size_t)newsize);
//		ft_bzero(input->line, MAXLINE);
//		input->line = ft_strcpy(input->line, residue);
//		TCLEAR_STR;
//		ft_putstr_fd(input->line, STDOUT_FILENO);
//		input->size -= newsize;
//		goto_start(input);
//		free(residue);
//	}
//	else
//		TBELL;
//}

void clear_input(t_readline *input)
{
	clear_visible_line(input);
	input->y = 0;
	input->size = 0;
	ft_bzero(input->line, MAXLINE);
	input->x = input->prompt_end;
}

void scroll_his_back(t_readline *input, t_history *history)
{
	if (history->cmnds && history->index > 0)
	{
		clear_input(input);
		char_enter(history->cmnds[history->index - 1], input);
		history->index--;
	}
	else
		TBELL;
}

void scroll_his_forward(t_readline *input, t_history *history)
{
	int tabsize;

	tabsize = str_quantity(history->cmnds);
	if (history->cmnds && history->index < tabsize - 1)
	{
		clear_input(input);
		char_enter(history->cmnds[history->index + 1], input);
		history->index++;
	}
	else
		TBELL;
}


char *get_hiscmnd(char *line, t_history *history)
{
	int		tabsize;

	if (!history->cmnds)
		return (NULL);
	tabsize = str_quantity(history->cmnds);
	while (tabsize--)
	{
		if (ft_strstr(history->cmnds[tabsize], line))
			return (ft_strdup(history->cmnds[tabsize]));
	}
	return (NULL);
}
//
//
int display_his_prompt()
{
	char *prompt;
	prompt = "history search> " ;
	ft_putstr_fd(BWHITE, STDOUT_FILENO);
	ft_putstr_fd(prompt, STDOUT_FILENO);
	ft_putstr_fd(RESET, STDOUT_FILENO);
	return ((int)ft_strlen(prompt));
}

char *autocompl(char *inputline, t_history *history)
{
	int		tabsize;
	char *cmnd;
	int i = 0;


	if (!history->cmnds)
		return (NULL);
	tabsize = str_quantity(history->cmnds);

	while (i < tabsize)
	{
		if ((cmnd = ft_strstr(history->cmnds[i], inputline)) && !ft_strncmp(history->cmnds[i], cmnd, ft_strlen(cmnd)))
			return (ft_strdup(cmnd));
		i++;
	}
	return (NULL);
}


void		his_search()
{
	char	*line;
	int prompt_sz;
	char	*cmnd;

	set_input_tmode();


int up;
up = g_shell->input->y;
while (up-- > 0)
{
	tputs(tgetstr("ce", NULL), 1, &ft_putchar_int);
	TUP;
}
	ft_putchar('\n');
	prompt_sz = display_his_prompt();
	ft_bzero(g_shell->input->line, MAXLINE);
	g_shell->input = init_readline(prompt_sz);
	readline_cmnd(&line, prompt_sz);
if (!ft_strcmp(line, "\n"))
{
	ft_putchar('\n');
	g_shell->input->mode = HISTORY_INPUT_STOP;

	reset_input_tmode();
	return;
}
	if ((cmnd = get_hiscmnd(line, g_shell->history)))
	    {
		goto_start(g_shell->input);
		tputs(tgetstr("ce", NULL), 1, &ft_putchar_int);
		ft_strcpy(g_shell->input->line, cmnd);
		ft_strcat(cmnd, "\n");
			ft_putstr_fd(cmnd, STDOUT_FILENO);
			free (cmnd);
    	}
	else
	    {
		ft_strcpy(g_shell->input->line, line);
		goto_start(g_shell->input);
		tputs(tgetstr("ce", NULL), 1, &ft_putchar_int);
		ft_putstr_fd("no matches found\n", STDOUT_FILENO);
		TBELL;
		}
	g_shell->input->mode = HISTORY_INPUT_STOP; //cmnd executes immediately
//	g_shell->input->mode = HISTORY_INPUT;
	reset_input_tmode();
}

int line_editor(char *buf, t_readline *input, t_history *history)
{
	if (g_shell->input->mode != HISTORY_INPUT_STOP)
	{
		if (ft_isprint(buf[0]) && char_enter(buf, input))
			return (0); //stop reading
		if (!ft_strcmp(buf, DEL))
			del_leftchar(input);
	}

	if (g_shell->input->mode != HISTORY_INPUT)
    {

        if (!ft_strcmp(buf, "\t"))
//            char_enter("\t", input);
        if (!ft_strcmp(buf, FN_DEL))
            del_rightchar(input); //fn del
        if (buf[0] == 12) //form feed
            clear_screen(input);
        if (buf[0] == 9 && char_enter(input->clipboard, input)) //paste
            return 0;
        if (buf[0] == 24) //ctrl X
            cut_after_cursor(input);
        if (buf[0] == 8) //ctrl h
            copy_before_cursor(input);
        if (buf[0] == 11) //ctrl k
            copy_after_cursor(input);
        if (!ft_strcmp(buf, FN_UP))
            scroll_his_back(input, history);
        if (!ft_strcmp(buf, FN_DOWN))
            scroll_his_forward(input, history);
        if (buf[0] == 18 && g_shell->input->mode == DEFAULT_INPUT) //ctrl R
		{
			g_shell->input->mode = HISTORY_INPUT;
			his_search();
		}

    }


//    if (buf[0] == ) ???
    //		cut_before_cursor(input);
	return (1);
}

void add_to_histfile()
{
	int		fd;
	int	i;
	char *path;

	path = g_shell->history->path;
	if ((fd = open(path, O_RDWR | O_TRUNC)) == -1)
		perror_cmnd(SHELLNAME, NULL, OPENERR);
	else
	{
		if (g_shell->history->index >= HISTFILESIZE)
			i = g_shell->history->index - HISTFILESIZE;
		else
			i = 0;
		while (g_shell->history->cmnds[i])
		{
			ft_putstr_fd(g_shell->history->cmnds[i], fd);
			ft_putchar_fd('\n', fd);
			i++;
		}
	}
	if (close(fd) == -1)
		perror_cmnd(SHELLNAME, NULL, CLOSEERR);
}

void history_add(char *line)
{
	char	**new;
	int		tabsize;
	int		i;
	char 	**tab;

	tab = g_shell->history->cmnds;
	if (tab)
		tabsize = str_quantity(tab) + 1;
	else
		tabsize = 1;
	if (!(new = (char **)malloc(sizeof(char *) * (tabsize + 1))))
		perror_cmnd(SHELLNAME, NULL, MLKERR);
	new[tabsize] = NULL;
	i = 0;
	if (tab)
	{
		while (i < tabsize - 1)
		{
			new[i] = ft_strdup(tab[i]);
			i++;
		}
	}
	new[i] = ft_strdup(line);
	clean_env(g_shell->history->cmnds);
	g_shell->history->cmnds = new;
	g_shell->history->index = tabsize;
	add_to_histfile();
}



//int check_quotes(const char *str)
//{
//    int i = 0;
//
//    int quotes = 0;
//
//    while (str[i] !=  '\0')
//    {
//        if (str[i] == 39)
//        {
//            quotes++;
//        }
//        i++;
//    }
//    if (quotes % 2 != 0)
//        return (1);
//    return 0;
//}
//
//
//int display_quote_prompt(int type)
//{
//    char *quoteprompt;
//    char *dquoteprompt;
//
//    quoteprompt = "quote> ";
//    dquoteprompt = "dquote> ";
//
//    if (type == 1)
//    {
//        g_shell->input->quotetype = 1;
//        ft_putstr_fd(quoteprompt, STDOUT_FILENO);
//        return ((int)ft_strlen(quoteprompt));
//    }
//    else if (type == 2)
//    {
//        g_shell->input->quotetype = 2;
//        ft_putstr_fd(dquoteprompt, STDOUT_FILENO);
//        return ((int)ft_strlen(dquoteprompt));
//    }
//    return (0);
//
//}

//void  quotes_search(int type)
//{
//
//    int prompt_sz;
//    char *line;
//
//
//
//    set_input_tmode();
//
////    oldpromptend = g_shell->input->prompt_end;
//
//    ft_putnbr(g_shell->input->quotetype);
//    ft_putstr_fd("\n", STDOUT_FILENO);
//    if (g_shell->input->mode == QUOTE_INPUT)
//        prompt_sz = display_quote_prompt(g_shell->input->quotetype);
//    else
//        prompt_sz = display_quote_prompt(type);
//
//
//    ft_bzero(g_shell->input->line, MAXLINE);
////    g_shell->input = init_readline(prompt_sz);
//    g_shell->input->y++;
//    g_shell->input->prompt_end = prompt_sz;
//    g_shell->input->x = prompt_sz;
//    g_shell->input->mode = QUOTE_INPUT;
//    readline_cmnd(&line, prompt_sz);
//
//    reset_input_tmode();
//}
void do_ctrl_d()
{
    if (g_shell->input->size == 0 && (g_shell->input->mode == DEFAULT_INPUT || g_shell->input->mode == HISTORY_INPUT))
    {
        reset_input_tmode();
        exit_clean();
    }
    else
        TBELL;
}

//void do_ctrl_g(char **line)
//{
//    TBELL;
//    g_shell->error = EXIT_FAILURE;
//    ft_bzero(g_shell->input->line, MAXLINE);
//    print_line(g_shell->input, 1);
//    *line = ft_strdup(g_shell->input->line);
////			free(g_shell->input->clipboard);
////			free(g_shell->input->line);
////			free(g_shell->input);
//}
void readline_cmnd(char **line, int prompt_size)
{
	char	buff[MAXREAD];

	set_input_tmode();

	g_shell->input = init_readline(prompt_size);
	g_shell->error = 0;
	while (1)
	{

		signals();
//		if (!init_keypad_transmitmode())
//		{
//			reset_input_tmode();
//			exit_clean();
//			exit_clean();
//		}

//if (g_shell->input->mode == HISTORY_INPUT_STOP) //cmnd executes immediately // decide: del or not
//{
//	*line = ft_strdup(ft_strcat(g_shell->input->line, "\0"));
//	g_shell->input->mode = DEFAULT_INPUT;
//	return ;
//}


		ft_bzero(buff, MAXREAD);
		read(STDIN_FILENO, buff, MAXREAD);

		if (g_shell->input->mode != HISTORY_INPUT && (g_shell->input->mode != HISTORY_INPUT_STOP))
			cursor_motion(g_shell->input, buff);


        if (*buff == EOT)
            do_ctrl_d();


		if (g_shell->sig == SIGINT)
		{
			g_shell->error = 1;
            *line = ft_strdup(ft_strcat(g_shell->input->line, "\0"));
g_shell->sig = 0;
//			g_shell->sig |= ~SIGINT;
			return;
		}

        if (!ft_strcmp(buff, EOL) || !line_editor(buff, g_shell->input, g_shell->history)) // \n
        {

			*line = ft_strdup(ft_strcat(g_shell->input->line, "\0"));

//			if (g_shell->input->mode != HISTORY_INPUT && (g_shell->input->mode != HISTORY_INPUT_STOP))
//				history_add(*line);
////


//             if (g_shell->input->mode == HISTORY_INPUT)
//             	ft_putchar('\n');
//
////				 print_line(g_shell->input, 0);
//			 }
//             else
			if (g_shell->input->mode != HISTORY_INPUT && (g_shell->input->mode != HISTORY_INPUT_STOP))
			{
				print_line(g_shell->input, 1);
//				free(g_shell->input->clipboard);
//				free(g_shell->input->line);
//				free(g_shell->input);
			}
            g_shell->input->mode = 0;

//			reset_input_tmode();
            return;
        }



		if (*buff == CTRL_G && g_shell->input->mode != HISTORY_INPUT) //bell
		{
			TBELL;
			g_shell->error = EXIT_FAILURE;
			ft_bzero(g_shell->input->line, MAXLINE);
			print_line(g_shell->input, 1);
			*line = ft_strdup(g_shell->input->line);
//			free(g_shell->input->clipboard);
//			free(g_shell->input->line);
//			free(g_shell->input);
			break ;
		}
	}
	reset_input_tmode();
}


int display_added_prompt(int  prompt_type)
{
    char *prompt;

    if (prompt_type == 1)
        prompt = "quote> ";
    else
        prompt = "dquote> ";
    ft_putstr_fd(BWHITE, STDOUT_FILENO);
    ft_putstr_fd(prompt, STDOUT_FILENO);
    ft_putstr_fd(RESET, STDOUT_FILENO);
    return ((int)ft_strlen(prompt));

}


int check_quote(char *line)
{

char *stack;
int q_count = 0;
int dq_count = 0;
int i = 0;

stack = ft_memalloc(1);
stack[0] = '0';
while (line[i])
{
    if (line[i] == 39)
    {
        if (stack[0] == '0')
            stack[0] = 39;
        q_count++;
    }
    else if (line[i] == 34)
    {
        if (stack[0] == '0')
            stack[0] = 34;
        dq_count++;
    }
    i++;
}
    if (q_count % 2 && stack[0] == 39)
    {
        free(stack);
        return (1);
    }
    else if (dq_count % 2 && stack[0] == 34)
    {
        free(stack);
        return (2);
    }
    free(stack);
    if (q_count % 2)
        return (1);
    else if (dq_count % 2)
        return (2);
    else
        return (0);
}

int repeat_check_quote(char *line, int quote_type)
{
    int i = 0;
    int count = 0;
    char c;
    if (quote_type == 1)
        c = 39;
    else
        c = 34;
    while (line[i])
    {
        if (line[i] == c)
            count++;
        i++;
    }
    return (count % 2);

}

char	*skip_quotes(const char *src, char q_type)
{
    int i;
    int j;
    char *clearline;

    clearline = ft_memalloc(MAXLINE);
    i = 0;
    j = 0;
    while (src[i])
    {
        while (src[j] == q_type)
            j++;
        clearline[i] = src[j];
        i++;
        j++;
    }
    clearline[i] = '\0';
    return (clearline);
}

void quote_readline(int quote_type)
{
    set_input_tmode();
    char *line;

    line = NULL;
    g_shell->input->mode = QUOTE_INPUT;
    readline_cmnd(&line, display_added_prompt(quote_type));
//    ft_strcat(g_shell->main_cmnd, skip_quotes(line, quote_type == 1 ? 39 : 34));
    ft_strcat(g_shell->main_cmnd, line);
    if (!repeat_check_quote(line, quote_type))
    {
        g_shell->main_cmnd = ft_strcat(g_shell->main_cmnd,"\n");
        quote_readline(quote_type);
    }
    reset_input_tmode();
}

void quote_output(char *line, int q_type)
{

    g_shell->main_cmnd = ft_strcpy(g_shell->main_cmnd, ft_strcat(skip_quotes(line, q_type == 1 ? 39 : 34), "\n"));
//    free (clearline);
    quote_readline(q_type);
}

//char *change_last_char(char *str, char c)
//{
//    int i = 0;
//
//    while (str[i])
//    {
//        if (str[i + 1] == '\0')
//        {
//            str[i] = c;
//            return (str);
//        }
//        i++;
//    }
//    return (NULL);
//}

void	cmnd_loop()
{

	char	*line;
	int		status;
	int prompt_size;

	status = 10;
	line = NULL;
	int q_type = 0;

	while (status)
	{
		signals();
		set_input_tmode();
        g_shell->main_cmnd = ft_memalloc(MAXLINE); //free!
		prompt_size = display_prompt();
		readline_cmnd(&line, prompt_size);
		if ((q_type = check_quote(line)))
            quote_output(line, q_type);
		else
            ft_strcpy(g_shell->main_cmnd, line);
        if (g_shell->input->mode != HISTORY_INPUT && (g_shell->input->mode != HISTORY_INPUT_STOP))
				history_add(g_shell->main_cmnd);
		if (line)
		{
		    action(g_shell->main_cmnd);
//            status = execution(g_shell->main_cmnd);
		    status--;
		}

	}
}
