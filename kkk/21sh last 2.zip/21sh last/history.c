//
// Created by Екатерина on 2019-10-03.
//

#include "minishell.h"

void scroll_his_back(t_readline *input, t_history *history)
{
	if (history->cmnds && history->index > 0)
	{
		clear_input(input);
		char_enter(history->cmnds[history->index - 1], input);
		history->index--;
	}
	else
		TBELL;
}

void scroll_his_forward(t_readline *input, t_history *history)
{
	int tabsize;

	tabsize = str_quantity(history->cmnds);
	if (history->cmnds && history->index < tabsize - 1)
	{
		clear_input(input);
		char_enter(history->cmnds[history->index + 1], input);
		history->index++;
	}
	else
		TBELL;
}


char *get_hiscmnd(char *line, t_history *history)
{
	int		tabsize;

	if (!history->cmnds)
		return (NULL);
	tabsize = str_quantity(history->cmnds);
	while (tabsize--)
	{
		if (ft_strstr(history->cmnds[tabsize], line))
			return (ft_strdup(history->cmnds[tabsize]));
	}
	return (NULL);
}

int display_his_prompt()
{
	char *prompt;
	prompt = "history search> " ;
	ft_putstr_fd(BWHITE, STDOUT_FILENO);
	ft_putstr_fd(prompt, STDOUT_FILENO);
	ft_putstr_fd(RESET, STDOUT_FILENO);
	return ((int)ft_strlen(prompt));
}

void		his_search()
{
	char	*line;
	int prompt_sz;
	char	*cmnd;

	set_input_tmode();


	int up;
	up = g_shell->input->y;
	while (up-- > 0)
	{
		tputs(tgetstr("ce", NULL), 1, &ft_putchar_int);
		TUP;
	}
	ft_putchar('\n');
	prompt_sz = display_his_prompt();
	ft_bzero(g_shell->input->line, MAXLINE);
	g_shell->input = init_readline(prompt_sz);
	readline_cmnd(&line, prompt_sz);
	if (!ft_strcmp(line, "\n"))
	{
		ft_putchar('\n');
		g_shell->inputmode = HISTORY_INPUT_STOP;

		reset_input_tmode();
		return;
	}
	if ((cmnd = get_hiscmnd(line, g_shell->history)))
	{
		goto_start(g_shell->input);
		tputs(tgetstr("ce", NULL), 1, &ft_putchar_int);
		ft_strcpy(g_shell->input->line, cmnd);
		ft_strcat(cmnd, "\n");
		ft_putstr_fd(cmnd, STDOUT_FILENO);
		free (cmnd);
	}
	else
	{
		ft_strcpy(g_shell->input->line, line);
		goto_start(g_shell->input);
		tputs(tgetstr("ce", NULL), 1, &ft_putchar_int);
		ft_putstr_fd("no matches found\n", STDOUT_FILENO);
		TBELL;
	}
	g_shell->inputmode = HISTORY_INPUT_STOP; //cmnd executes immediately
//	g_shell->input->mode = HISTORY_INPUT;
	reset_input_tmode();
}