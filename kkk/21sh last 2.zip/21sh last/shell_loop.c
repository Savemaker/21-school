/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   shell_loop.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bellyn-t <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/08 13:48:14 by bellyn-t          #+#    #+#             */
/*   Updated: 2019/09/08 13:48:17 by bellyn-t         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */



//his scroll when quotes
//ctrl d
//ctrl c
//autocom
//leaks


#include "minishell.h"

int		str_quantity(char **env)
{
	int i;

	i = 0;
	while (env[i])
		i++;
	return (i);
}

int ft_putchar_int(int c)
{
	write(STDOUT_FILENO, &c, 1);
	return (1);
}

t_readline *init_readline(int prompt_size)
{
	struct winsize	win;
	t_readline *input;

//	int savemode = 0;
//
//	if (g_shell->input)
//		savemode = g_shell->input->mode;
	input = ft_memalloc(sizeof(t_readline));
//	input->mode = savemode;
//	ft_bzero(input, sizeof(t_readline));
	input->line = ft_memalloc(MAXLINE);
	input->clipboard = ft_memalloc(MAXLINE);
	if ((ioctl(STDIN_FILENO, TIOCGWINSZ, &win)) == -1)
	{
		ft_putchar('\n');
		perror_cmnd(SHELLNAME, NULL, IOCTLERR);
		exit_clean();
	}
	input->maxwidth = win.ws_col;
	input->maxheight = win.ws_row;
	if (prompt_size >= (input->maxwidth))
	{
		input->prompt_end = prompt_size % (input->maxwidth);
		if (input->prompt_end == 0)
			TDOWN;
	}
	else
		input->prompt_end = prompt_size;
	input->x = input->prompt_end;
	input->prompt_size = prompt_size;
	return (input);
}



void print_line(t_readline *input, int eof)
{
	clear_visible_line(input);
	ft_putstr_fd(input->line, STDOUT_FILENO);
	if (eof)
	    ft_putchar_fd('\n', STDOUT_FILENO);
}



static void	cursor_motion(t_readline *input, char *buf) //ok
{
//	if (!ft_strcmp(buf, tgetstr("nd", NULL)))
//	if (!ft_strcmp(buf, tgetstr("kr", NULL)))
    if (!ft_strcmp(buf, RIGHT_KEY))
		cursor_right(input);

	if (!ft_strcmp(buf, LEFT_KEY))
//	if (!ft_strcmp(buf, tgetstr("kl", NULL)))
		cursor_left(input);
//	if (!ft_strcmp(buf, tgetstr("ku", NULL)))
	else if (!ft_strcmp(buf, UP_KEY))
		cursor_up(input);
//	if (!ft_strcmp(buf, tgetstr("kd", NULL)))
	else if (!ft_strcmp(buf, DOWN_KEY))//
		cursor_down(input);
	else if (!ft_strcmp(buf, CTRL_A) || !ft_strcmp(buf, FN_LEFT)) ////ctrl A  || fn < (home)
//	else if (!ft_strcmp(buf, CTRL_A) || !ft_strcmp(buf,tgetstr("kh", NULL))) ////ctrl A  || fn < (home)
		goto_start(input);
	else if (!ft_strcmp(buf, CTRL_E) || !ft_strcmp(buf, FN_RIGHT)) ////ctrl E  || fn > (end)
//	else if (!ft_strcmp(buf, CTRL_E) || !ft_strcmp(buf, tgetstr("kh", NULL)))
		goto_end(input);
	else if (!ft_strcmp(buf, CTRL_F))
		goto_next_word(input);
	else if (!ft_strcmp(buf, CTRL_B))
		goto_prev_word(input);

}

void	autocom_addpath(t_list *list, char *clear_path, char *request_path)
{
	char		*full_path;
	DIR			*dir;
	struct dirent	*dir_ptr;
	struct stat stat;

	if ((dir = opendir(clear_path)))
	{
		while ((dir_ptr = readdir(dir)))
		{
			if (dir_ptr->d_name[0] != '.' && !ft_strncmp(dir_ptr->d_name, request_path, ft_strlen(request_path)))
			{
				full_path = ft_memalloc(MAXLINE);
				full_path = ft_strcpy(full_path, clear_path);
				full_path = ft_strcat(full_path, "/");
				full_path = ft_strcat(full_path, dir_ptr->d_name);

				if (lstat(full_path, &stat) == -1)
					perror_cmnd(SHELLNAME, NULL, LSTATERR);
				if (S_ISDIR(stat.st_mode))
					full_path = ft_strcat(full_path, "/");

				ft_lstadd(&list, ft_lstnew(full_path, ft_strlen(full_path) + 1));
				free(full_path);
			}
		}
		closedir(dir);
	}

}


int ft_lstsize(t_list *lst)
{
	int i = 0;

	while (lst)
	{
		lst = lst->next;
		i++;
	}
	return (i);
}


char	*autocom_path(t_list *list, char *searching_path, char *request_path)
{
	char	*clear_path;
//	char	*query_path;

//	request = ft_strrchr(search, '/') + 1;


//	request = ft_strnew(ft_strlen(search) - ft_strlen(request_pathpos) + 1); //лучше так

	clear_path = ft_memalloc(MAXLINE);
	ft_strncpy(clear_path, searching_path, ft_strlen(searching_path) - ft_strlen(request_path));


	autocom_addpath(list, clear_path, request_path);

	if (!ft_lstsize(list))
		return (NULL);
	else if (ft_lstsize(list) == 1)
		return ((char *)list->content) + ft_strlen(request_path);

	return ("hehe");
//	return (shell_autocompletion_compute(*list, *list, request));
}



char	*get_autocom(char *request)
{

	char	*response;

	char *request_pathpos;


	t_list	*result;
//	t_list	*tmp;

response = NULL;
	set_input_tmode();
	result = NULL;

	if ((request_pathpos = ft_strrchr(request, '/')))
		response = ft_strdup(autocom_path(result, request, request_pathpos));

//	else
//		output = shell_autocompletion_search_env(sh, &results, search);


//free result !!!

	return (response);
}


void autocom(t_readline *input, char *buf)
{
	
//	char *response;
//
//	int bufsize;
//
//	response = get_autocom(buf);
//	bufsize = (int)ft_strlen(response) - input->size;
//	if (input->size < MAXLINE - bufsize)
//	{
////		pos = input->y * input->maxwidth + input->x - input->prompt_end;
////		ft_bzero(input->line + pos, (size_t)MAXLINE - pos);
//ft_bzero(input->line, MAXLINE);
//		input->line = ft_strcpy(input->line, response);
//
//		clear_visible_line(input);
//		ft_putstr(input->line);
//
//		input->size += bufsize;
//		goto_lastsymb(input);
//		while (bufsize-- > 0)
//			cursor_right(input);
////		free(residue);
//	}
//	else
		TBELL;


}

void line_editing(char *buf, t_readline *input, t_history *history)
{
	if (g_shell->inputmode != HISTORY_INPUT_STOP)
	{
		if (ft_isprint(buf[0]))
		{
			char_enter(buf, input);
//			return (0); //stop reading
		}
		if (!ft_strcmp(buf, DEL))
			del_leftchar(input);
	}

	if (g_shell->inputmode != HISTORY_INPUT)
    {

        if (!ft_strcmp(buf, "\t"))//???
        	autocom(input, buf);
        if (!ft_strcmp(buf, FN_DEL))
            del_rightchar(input); //fn del
        else if (buf[0] == 12) //form feed
            clear_screen(input);
        else if (buf[0] == 9)
        	char_enter(input->clipboard, input); //paste
        else if (buf[0] == 24) //ctrl X
            cut_after_cursor(input);
		else if (buf[0] == 8) //ctrl h
            copy_before_cursor(input);
		else if (buf[0] == 11) //ctrl k
            copy_after_cursor(input);
		else if (!ft_strcmp(buf, FN_UP))
            scroll_his_back(input, history);
		else if (!ft_strcmp(buf, FN_DOWN))
            scroll_his_forward(input, history);
		else if (buf[0] == 18 && g_shell->inputmode == DEFAULT_INPUT) //ctrl R
		{
			g_shell->inputmode = HISTORY_INPUT;
			his_search();
		}
    }


//    if (buf[0] == ) ???
    //		cut_before_cursor(input);
}

void add_to_histfile()
{
	int		fd;
	int	i;
	char *path;

	path = g_shell->history->path;
	if ((fd = open(path, O_RDWR | O_TRUNC)) == -1)
		perror_cmnd(SHELLNAME, NULL, OPENERR);
	else
	{
		if (g_shell->history->index >= HISTFILESIZE)
			i = g_shell->history->index - HISTFILESIZE;
		else
			i = 0;
		while (g_shell->history->cmnds[i])
		{
			ft_putstr_fd(g_shell->history->cmnds[i], fd);
			ft_putchar_fd('\n', fd);
			i++;
		}
	}
	if (close(fd) == -1)
		perror_cmnd(SHELLNAME, NULL, CLOSEERR);
}

void history_add(char *line)
{
	char	**new;
	int		tabsize;
	int		i;
	char 	**tab;

	tab = g_shell->history->cmnds;
	if (tab)
		tabsize = str_quantity(tab) + 1;
	else
		tabsize = 1;
	if (!(new = (char **)malloc(sizeof(char *) * (tabsize + 1))))
		perror_cmnd(SHELLNAME, NULL, MLKERR);
	new[tabsize] = NULL;
	i = 0;
	if (tab)
	{
		while (i < tabsize - 1)
		{
			new[i] = ft_strdup(tab[i]);
			i++;
		}
	}
	new[i] = ft_strdup(line);
	clean_env(g_shell->history->cmnds);
	g_shell->history->cmnds = new;
	g_shell->history->index = tabsize;
	add_to_histfile();
}

void do_ctrl_d()
{
    if (g_shell->input->size == 0 && (g_shell->inputmode == DEFAULT_INPUT || g_shell->inputmode == HISTORY_INPUT))
    {
        reset_input_tmode();
        exit_clean();
    }
    else
        TBELL;
}

void do_ctrl_g(char **line)
{
    TBELL;
    g_shell->error = EXIT_FAILURE;
    ft_bzero(g_shell->input->line, MAXLINE);
    print_line(g_shell->input, 1);
    *line = ft_strdup(g_shell->input->line);
}

void do_sigint(char **line) //???
{
	g_shell->error = 1;
	*line = ft_strdup("\0");
//            *line = ft_strdup(ft_strcat(g_shell->input->line, "\0"));
	print_line(g_shell->input, 1);
	reset_input_tmode();
}


int action_signs(char *buff, char **line)
{
	if (*buff == EOT)
		do_ctrl_d();

	if (g_shell->sig == SIGINT)
	{
		do_sigint(line);
		return 1;
	}
	if (!ft_strcmp(buff, EOL)) // \n
	{
		*line = ft_strdup(ft_strcat(g_shell->input->line, "\0"));
		if (g_shell->inputmode != HISTORY_INPUT && (g_shell->inputmode != HISTORY_INPUT_STOP))
			print_line(g_shell->input, 1);
		return 1;
	}
	if (*buff == CTRL_G && g_shell->inputmode != HISTORY_INPUT) //bell
	{
		do_ctrl_g(line);
		return 1;
	}
	return (0);
}




//char	*shell_autocompletion_compute(t_list *cur, t_list *list,
//									  char *query)
//{
//	char	*result;
//	int		i;
//
//	i = ft_strlen(query) - 1;
//	result = ft_strdup(query);
//	while (++i != -1 && (cur = list))
//	{
//		while (cur && i != -1)
//		{
//			if (ft_strncmp(result, cur->content, i) != 0)
//			{
//				result = ft_strdup(cur->content);
//				result[i - 1] = 0;
//				i = -1;
//				return (result + ft_strlen(query));
//			}
//			else
//			{
//				free(result);
//				result = ft_strdup(cur->content);
//			}
//			cur = cur->next;
//		}
//	}
//	return (NULL);
//}



void readline_cmnd(char **line, int prompt_size)
{
	char	buff[MAXREAD];

	set_input_tmode();
	g_shell->input = init_readline(prompt_size);
	g_shell->error = 0;
	while (1)
	{
		signals();
		ft_bzero(buff, MAXREAD);
		read(STDIN_FILENO, buff, MAXREAD);
		if (g_shell->inputmode != HISTORY_INPUT && (g_shell->inputmode != HISTORY_INPUT_STOP))
			cursor_motion(g_shell->input, buff);
		line_editing(buff, g_shell->input, g_shell->history);
		if (action_signs(buff, line)) //ctrl d c g // sig int // \n
		{
			reset_input_tmode();
			return;
		}
	}
}


void	cmnd_loop()
{

	char	*line;
	int		status;

	status = 1;
	line = NULL;
	int q_type = 0;

	while (status)
	{
		signals();
		set_input_tmode();
        g_shell->main_cmnd = ft_memalloc(MAXLINE); //free!
        g_shell->inputmode = DEFAULT_INPUT;
		g_shell->sig = 0;
		readline_cmnd(&line, display_prompt());
		if ((q_type = check_quote(line)))
            quote_output(line, q_type);
		else
            ft_strcpy(g_shell->main_cmnd, line);
		if (line && !g_shell->sig)
		{
			if (g_shell->inputmode != HISTORY_INPUT && (g_shell->inputmode != HISTORY_INPUT_STOP))
				history_add(g_shell->main_cmnd);
			status = execution(g_shell->main_cmnd);
		}

	}
}
