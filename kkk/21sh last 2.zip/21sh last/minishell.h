/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bellyn-t <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/07 21:40:47 by bellyn-t          #+#    #+#             */
/*   Updated: 2019/09/08 16:09:25 by bellyn-t         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
# define MINISHELL_H

# define SHELLNAME "21sh"


/*
** Termcaps
*/

# define TUP tputs(tgetstr("up", NULL), 1, &ft_putchar_int)
# define TLEFT_BORDER tputs(tgetstr("cr", NULL), 1, &ft_putchar_int)
# define TDOWN tputs(tgetstr("sf", NULL), 1, &ft_putchar_int)
# define TRIGHT tputs(tgetstr("nd", NULL), 1, &ft_putchar_int)
# define TLEFT tputs(tgetstr("le", NULL), 1, &ft_putchar_int)
# define TBELL tputs(tgetstr("bl", NULL), 1, &ft_putchar_int)
# define TCLEAR_STR tputs(tgetstr("cd", NULL), 1, &ft_putchar_int)
# define TDEL_CHAR tputs(tgetstr("dc", NULL), 1, &ft_putchar_int)


/*
** Modes
*/

# define DEFAULT_INPUT 0
# define HISTORY_INPUT 1
# define HISTORY_INPUT_STOP 2
# define QUOTE_INPUT 3

/*
** History
*/
# define HISTSIZE 500
# define HISTFILESIZE 500
# define HISTFILE "/.21sh_history"



# include "libft/libft.h"
# include <stdlib.h>
# include <sys/types.h>
# include <sys/wait.h>
# include <sys/stat.h>
# include <unistd.h>
# include <dirent.h>
# include <stdio.h>
# include <sys/dir.h>
# include <string.h>
# include <signal.h>
# include <readline/readline.h>
# include <readline/history.h>
# include <setjmp.h>
#include <termios.h>
#include <termcap.h>
#include <pwd.h>
#include <fcntl.h>
#include "get_next_line/get_next_line.h"


/*
** Error
*/
# define NOTINPWD 1
# define MNARGS 2
# define GETCWDERR 3
# define LSTATERR 4
# define STATERR 5
# define CMNDNTFND 6
# define EXECVEERR 7
# define FORKERR 8
# define MLKERR 9
# define NOTDIR 10
# define CHDIRERR 11
# define SETENVERR 12
# define NOFLODIR 13
# define PMDND 14
# define TCGETATTR 15
# define NOTTERM 16
# define TCSETATTR 17
# define TTYNOTDFND 18
# define NOTERMCAP 19
# define SPECTTY 20
# define IOCTLERR 21
# define OPENERR 22
# define CLOSEERR 23

/*
**
*/
# define MAXDIR 4095
# define MAXLINE 2048
# define MAXHOSTNAME 64
# define MAXREAD 5





/*
** Symbs
*/
# define EOT '\004' //^D end of transmission
# define EOL "\n" //\n
# define CTRL_G '\007' //bell
#define CTRL_A "\001"
#define CTRL_E "\005"
#define CTRL_F "\006"
#define CTRL_B "\002"
#define DEL "\177"
#define CTRL_L "\012"

#define FN_LEFT "\E[H"
#define FN_RIGHT "\E[F"

#define FN_UP "\E[5~"
#define FN_DOWN "\E[6~"
#define FN_DEL "\E[3~"

# define RIGHT_KEY "\E[C"
# define LEFT_KEY "\E[D"
# define UP_KEY "\E[A"
# define DOWN_KEY "\E[B"

/*
** Reset Color
*/
# define RESET "\033[0m"

/*
** Regular
*/
# define BLACK  	"\033[0;30m"
# define RED		"\033[0;31m"
# define GREEN		"\033[0;32m"
# define YELLOW		"\033[0;33m"
# define BLUE		"\033[0;34m"
# define MAGENTA	"\033[0;35m"
# define CYAN		"\033[0;36m"
# define WHITE		"\033[0;37m"

/*
** Bold
*/
# define BBLACK 	"\033[1;30m"
# define BRED		"\033[1;31m"
# define BGREEN		"\033[1;32m"
# define BYELLOW	"\033[1;33m"
# define BBLUE		"\033[1;34m"
# define BMAGENTA	"\033[1;35m"
# define BCYAN		"\033[1;36m"
# define BWHITE		"\033[1;37m"

/*
** Underline
*/
# define UBLACK  	"\033[4;30m"
# define URED		"\033[4;31m"
# define UGREEN		"\033[4;32m"
# define UYELLOW	"\033[4;33m"
# define UBLUE		"\033[4;34m"
# define UMAGENTA	"\033[4;35m"
# define UCYAN		"\033[4;36m"
# define UWHITE		"\033[4;37m"

/*
** Background
*/
# define BGBLACK 	"\033[40m"
# define BGRED		"\033[41m"
# define BGGREEN	"\033[42m"
# define BGYELLOW	"\033[43m"
# define BGBLUE		"\033[44m"
# define BGMAGENTA	"\033[45m"
# define BGCYAN		"\033[46m"
# define BGWHITE	"\033[47m"


# define SHELL_NAME "\e[95m\e[1mminishell\e[0m🌚  "









typedef struct		s_readline
{
	char			*line;
	char			*clipboard;
	int				maxwidth;
	int				maxheight;
	int				size;
	int				x;
	int				y;
	int				prompt_end;
	int				prompt_size;
//	int 	    	mode;
}					t_readline;


typedef struct		s_history
{
	char 			**cmnds;
	int 			index;
	char 			*path;
	int 			size; //кол-во команд в списке
//	int 			filesize; //кол-во строк в баффе
}					t_history;

typedef struct	s_shell
{
	char		**env;
    char        *main_cmnd;
	t_readline	*input;
	int			error;
	int			sig;
	t_history 	*history;
	int 	    inputmode;
}				t_shell;


struct termios g_saved_attributes;
t_shell			*g_shell;

int		launch(char *file, char **args, int absolute);
int		absolute_path_launch(char **cmnd);
void	print_env(char **env);
int		env_cmnd(void);
int		exit_cmnd(void);
int		check_builtin(char *cmnd);
int		builtin(char **args);
void	launch_cd(char *path);
int		cd_cmnd(char **args, int argc);
int		echo_cmnd(char **args);
char	*check_error_code(int error_code);
char	*check_error_code_dope(int error_code);
void	perror_cmnd(char *cmnd, char *error_path, int error_code);
int		find_bin(char *cmnd_name, char *path);
char	*path(char *name, char *path);
char	*check_extern_command(char **cmnd, int i);
int		external_launch(char **cmnd, char *paths);
void	clean_env(char **env_cp);
void	free_parse(char **parse, int w);
void	free_copy_envp(char ***envp);
int		str_quantity(char **env);
int		check_existenv(const char *name, char *request);
int		get_envindex(const char *name);
int		checkenv(char *envstr);
char	*getenv_cmnd(char *name);
int		execute_cmnd(char **cmnd);
char	**make_env_cp(char **env_origin);
void	print_usage(void);
int		main(int argc, char **argv, char **env);
void	join_value(char **ress, char *name, char *value);
void	copy_to_realloc(char **envp, char **res, char *name, char *value);
char	**realloc_envp(int pointers, char *name, char *value, char **env);
int		setenv_cmnd(char *name, char *value);
//void	cmnd_loop(void);
void	signals(void);
void	handler_interrupt(int signal);
char	*check_sig_code(int sig_code);
char	**split(char **str, char *s, char c, int count);
int		count_words(char *str, char sign);
char	**split_cmnd(char const *s, char c);
void	copy_realloc_del(char **res, char **env, int index);
char	**realloc_envp_del(int p, char *name, char **env);
int		unsetenv_cmnd(char *name);
int		env_strlen(char *s);
char	*cmnd_generator(const char *text, int state);
char	**cmnd_completion(const char *text, int start, int end);
int		getenv_strlen(char *str);
char	*malloc_line(char *name, char *value);
int		execute_cmnd(char **cmnd);
int		exe_multcmnds(char *line);
int		exe_cmnds(char *line);
int		execution(char *line);
void	check_cd(int argc, char **args, int cwderr);


//int		execution(char *line, t_history *history);
//void readline_cmnd(char **line, int prompt_size);

void readline_cmnd(char **line, int prompt_size);

void	cmnd_loop();
int display_history(char **cmnd);
int ft_nbrlen(int nb);
//void init_readline(t_readline *input, int prompt_size);
void	handler_win(int sig);
t_readline *init_readline(int prompt_size);






/*
** quotes
*/
void quote_output(char *line, int q_type);
void quote_readline(int quote_type);
char	*skip_quotes(const char *src, char q_type);
char *change_last_char(char *str, char c);
int repeat_check_quote(char *line, char c);
int check_quote(char *line);
int display_added_prompt(int  prompt_type);

/*
** prompt
*/
int display_prompt(void);
int display_ordinary_prompt();
int display_cwd(void);
int display_host(void);
int display_user(void);





int ft_putchar_int(int c);


/*
** cursor move
*/
void	cursor_down(t_readline *input);
void	goto_lastsymb(t_readline *input);
void	cursor_up(t_readline *input);
void cursor_left(t_readline *input);
void cursor_right(t_readline *input);


/*
** goto
*/
void goto_inputstart(t_readline *input);
void goto_linestart(t_readline *input);
void goto_start(t_readline *input);
void goto_end(t_readline *input);
void goto_next_word(t_readline *input);
void goto_prev_word(t_readline *input);

/*
** cut copy
*/
void cut_after_cursor(t_readline *input);
void copy_before_cursor(t_readline *input);
void copy_after_cursor(t_readline *input);

/*
** enter del char
*/
void	del_leftchar(t_readline *input);
void	del_rightchar(t_readline *input);
void	char_enter(char *buf, t_readline *input);

/*
** clearing
*/
void clear_input(t_readline *input);
void clear_screen(t_readline *input);
void clear_visible_line(t_readline *input);


/*
** history
*/
void		his_search();
int display_his_prompt();
char *get_hiscmnd(char *line, t_history *history);
void scroll_his_forward(t_readline *input, t_history *history);
void scroll_his_back(t_readline *input, t_history *history);


/*
** init term
*/
t_history *init_history();
void set_input_tmode(void);
void init_term(void);
void exit_clean(void);
void reset_input_tmode(void);


#endif
