//
// Created by Екатерина on 2019-10-03.
//

#include "minishell.h"

int display_user(void)
{
	char	*user;
	int len;
//	if (!g_shell.error)
	ft_putstr_fd(BGREEN, STDOUT_FILENO);
//	else
//		ft_putstr_fd(BRED, STDOUT_FILENO);
	if ((user = getenv_cmnd("USER")))
	{
		ft_putstr_fd(user, STDOUT_FILENO);
		len = (int)ft_strlen(user);
	}
	else
	{
		ft_putstr_fd(SHELLNAME, STDOUT_FILENO);
		len = (int)ft_strlen(SHELLNAME);
	}
	return (len);
}

int display_host(void)
{
	char	host[MAXHOSTNAME];

	gethostname(host, MAXHOSTNAME);
	ft_putchar_fd('@', STDOUT_FILENO);
	ft_putstr_fd(host, STDOUT_FILENO);
	return ((int)ft_strlen(host) + 1);
}

int display_cwd(void)
{
	char	*cwd;
	char 	*newcwd;
	char 	*val;
	int 	len;

	len = 0;
	if ((cwd = getcwd(NULL, 0)))
	{
		ft_putstr_fd(WHITE, STDOUT_FILENO);
		ft_putstr_fd(":", STDOUT_FILENO);
		ft_putstr_fd(BCYAN, STDOUT_FILENO);
		val = getenv_cmnd("HOME");
		if (!ft_strncmp(cwd, val, ft_strlen(val)))
		{
			newcwd = ft_strjoin("~", cwd + ft_strlen(val));
			ft_putstr(newcwd);
			len = (int)ft_strlen(newcwd);
			free(newcwd);
		}
		else
		{
			ft_putstr_fd(cwd, STDOUT_FILENO);
			len = (int)ft_strlen(cwd);
		}
	}
	free(cwd);
	return (len + 1);
}

int display_ordinary_prompt()
{
	int len;

	len = 0;
	len += display_user();
	len += display_host();
	len += display_cwd();
	if (!g_shell->error)
		ft_putstr_fd(BGREEN, STDOUT_FILENO);
	else
		ft_putstr_fd(BRED, STDOUT_FILENO);
//	ft_putstr_fd("$ ", STDOUT_FILENO);
	ft_putstr_fd(" ➜  ", STDOUT_FILENO);
	ft_putstr_fd(RESET, STDOUT_FILENO);
	return (len + 4);
}

void display_def_prompt(char *defprompt)
{
	defprompt = NULL;
}


//int	init_keypad_transmitmode(void)
//{
//	if (tgetstr("ks", NULL))
//		tputs(tgetstr("ks", NULL), 1, &ft_putchar_int);
//	else
//	{
//		ft_putchar_fd('\n', STDOUT_FILENO);
//		perror_cmnd(SHELLNAME, "no correct capabilities", 0);
//		return (0);
//	}
//	return (1);
//}

int display_prompt(void)
{
	int len;

	set_input_tmode();

//	if ((default_prompt = getenv_cmnd("PS1")))
//		display_def_prompt(default_prompt);
//	else
	len = display_ordinary_prompt();
	reset_input_tmode();
	return (len);
}